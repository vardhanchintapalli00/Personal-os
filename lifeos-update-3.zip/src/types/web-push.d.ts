declare module 'web-push';
